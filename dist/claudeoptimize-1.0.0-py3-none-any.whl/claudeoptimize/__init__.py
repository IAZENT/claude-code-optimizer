"""claudeoptimize package."""
